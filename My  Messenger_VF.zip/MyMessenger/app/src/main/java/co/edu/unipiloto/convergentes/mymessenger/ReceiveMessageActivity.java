package co.edu.unipiloto.convergentes.mymessenger;

import static co.edu.unipiloto.convergentes.mymessenger.MainActivity.historial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class ReceiveMessageActivity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "message";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_message);

        //recibir el mensaje y mostrarlo en la pantalla
        Intent intent = getIntent();
        String messageText = intent.getStringExtra(EXTRA_MESSAGE);
        TextView messageView = (TextView) findViewById(R.id.message);

        String hist = "";
        if (historial.isEmpty()){
            messageView.setText("");
        }else {
            for (String s: historial ) {
                hist += s + "\n";
            }
            //hist += messageText;
            messageView.setText(hist);
        }


    }

    public void onSendReply(View view){
        //Enviar respuesta
        EditText replyView =(EditText) findViewById(R.id.messageSend);
        String replyText = replyView.getText().toString();
        historial.add(replyText);
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra(MainActivity.EXTRA_REPLY, replyText);
        startActivity(i);
    }
}