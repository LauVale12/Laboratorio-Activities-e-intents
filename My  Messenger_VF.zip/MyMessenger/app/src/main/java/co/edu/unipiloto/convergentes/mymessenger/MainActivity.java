package co.edu.unipiloto.convergentes.mymessenger;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_REPLY = "message";
    public static List<String> historial = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Intent i = getIntent();
        String replyText = i.getStringExtra(EXTRA_REPLY);
        TextView replyView = (TextView) findViewById(R.id.messageReply);
        String hist = "";
        if (historial.isEmpty()){
            replyView.setText("");
        }else {
            for (String s : historial) {
                hist += s + "\n";
            }
        //hist += replyText;
            replyView.setText(hist);
        }


    }

    //Llamar onSendMessage() cuando el boton sea clickeado
    public void onSendMessage(View view){
        EditText messageView =(EditText) findViewById(R.id.message);
        String messageText = messageView.getText().toString();
        historial.add(messageText);
        //Enviar mensaje a la otra clase
        Intent intent = new Intent(this, ReceiveMessageActivity.class);
        intent.putExtra(ReceiveMessageActivity.EXTRA_MESSAGE, messageText);
        startActivity(intent);

    }
}